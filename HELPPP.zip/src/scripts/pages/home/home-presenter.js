import HomeModel from './home-model.js';

export default class HomePresenter {
  constructor(view) {
    this.view = view;
    this.model = new HomeModel();
  }

  async init() {
    try {
      // Check authentication status
      if (!this.model.isUserAuthenticated()) {
        this.view.navigateToLogin();
        return;
      }

      // Load stories
      await this.loadStories();

    } catch (error) {
      console.error('Init error:', error);
      this.view.showError('Gagal memuat halaman');
    }
  }

  async loadStories() {
    try {
      this.view.showLoading();

      // Fetch stories through model
      await this.model.fetchStories();

      // Get processed data from model
      const stories = this.model.prepareStoryListData();
      const mapData = this.model.prepareMapData();

      console.log('Stories loaded:', stories.length);

      // Update view with data
      this.view.displayStories(stories);
      this.view.displayMap(mapData);

    } catch (error) {
      console.error('Load stories error:', error);

      // Handle different error types
      let errorMessage = this.determineErrorMessage(error);

      if (error.message.includes('token') || error.message.includes('authentication')) {
        this.view.handleSessionExpiry();
      }

      this.view.showError(errorMessage);
    } finally {
      this.view.hideLoading();
    }
  }

  determineErrorMessage(error) {
    if (error.message.includes('token') || error.message.includes('authentication')) {
      return 'Sesi Anda telah berakhir. Silakan login kembali.';
    } else if (error.message.includes('Network') || error.message.includes('fetch')) {
      return 'Tidak dapat terhubung ke server. Periksa koneksi internet Anda.';
    } else {
      return error.message || 'Terjadi kesalahan yang tidak diketahui';
    }
  }

  async refreshStories() {
    await this.loadStories();
  }

  logout() {
    // Clear model data and user session
    this.model.clearCache();
    this.model.clearUserSession();
    this.view.handleLogout();
  }

  // Search functionality
  filterStories(searchText) {
    // Use model to search stories
    const filteredStories = this.model.searchStories(searchText);
    const mapData = this.model.prepareMapData();

    console.log(`Filtered ${filteredStories.length} stories from ${this.model.getStoriesCount()} total`);
    
    // Update view with filtered data
    this.view.displayStories(filteredStories);
    this.view.displayMap(mapData);
  }

  clearSearch() {
    const allStories = this.model.clearSearch();
    const mapData = this.model.prepareMapData();
    
    this.view.displayStories(allStories);
    this.view.displayMap(mapData);
  }

  // Navigation requests
  navigateToStoryDetail(storyId) {
    if (!storyId) {
      console.error('Story ID is required');
      return;
    }

    // Validate story exists in model
    const story = this.model.getStoryById(storyId);
    if (!story) {
      this.view.showError('Story tidak ditemukan');
      return;
    }

    this.view.navigateToStoryDetail(storyId);
  }

  navigateToAddStory() {
    this.view.navigateToAddStory();
  }

  // Data access methods (delegated to model)
  getStoriesCount() {
    return this.model.getStoriesCount();
  }

  getStoriesWithLocation() {
    return this.model.getStoriesWithLocation();
  }

  getStatistics() {
    return this.model.getStatistics();
  }

  // Silent refresh without UI feedback
  async silentRefresh() {
    try {
      await this.model.refreshData();
      
      const stories = this.model.prepareStoryListData();
      const mapData = this.model.prepareMapData();
      
      this.view.displayStories(stories);
      this.view.displayMap(mapData);
      return true;
    } catch (error) {
      console.error('Silent refresh error:', error);
      return false;
    }
  }

  // Sort functionality
  sortStoriesByDate(ascending = false) {
    const sortedStories = this.model.sortStoriesByDate(ascending);
    const mapData = this.model.prepareMapData();
    
    this.view.displayStories(sortedStories);
    this.view.displayMap(mapData);
  }

  // Handle user interactions
  onStoryCardClick(storyId) {
    this.navigateToStoryDetail(storyId);
  }

  onLocationButtonClick(lat, lon) {
    // Validate coordinates
    if (isNaN(lat) || isNaN(lon)) {
      this.view.showError('Koordinat lokasi tidak valid');
      return;
    }
    
    this.view.centerMapOnLocation(lat, lon);
  }

  onAddStoryClick() {
    this.navigateToAddStory();
  }

  onRefreshClick() {
    this.refreshStories();
  }

  onLogoutClick() {
    this.view.showLogoutConfirmation();
  }

  onLogoutConfirmed() {
    this.logout();
  }

  onSearchInput(searchText) {
    this.filterStories(searchText);
  }

  onSearchClear() {
    this.clearSearch();
  }

  onRetryClick() {
    this.refreshStories();
  }

  onSortClick(ascending = false) {
    this.sortStoriesByDate(ascending);
  }

  // Get current state from model
  getCurrentSearchQuery() {
    return this.model.getCurrentSearchQuery();
  }

  isLoading() {
    return this.model.getLoadingState();
  }

  hasError() {
    return this.model.hasError();
  }

  getError() {
    return this.model.getError();
  }
}