import "../../../styles/home.css";
import HomePresenter from './home-presenter.js';

export default class HomePage {
  constructor() {
    this.presenter = new HomePresenter(this);
    this.map = null;
    this.markers = [];
    this.searchTimeout = null; // For debouncing search
  }

  async render() {
    return `
      <!-- Header -->
      <header class="home-header">
        <div class="header-content">
          <h1 class="welcome-message">
            Selamat datang, <span id="username">User</span>!
          </h1>
          <div class="header-actions">
            <button id="addStoryBtn" class="btn btn-primary">
              <span class="icon">+</span>
              Tambah Story
            </button>
            <button id="refreshBtn" class="btn btn-secondary">
              <span class="icon">↻</span>
              Refresh
            </button>
            <button id="logoutBtn" class="btn btn-danger">
              <span class="icon">↪</span>
              Logout
            </button>
          </div>
        </div>
      </header>

      <!-- Home Content Area - This is where focus should go when Skip to Content is used -->
      <section id="main-content" class="home-main-content" tabindex="-1" aria-label="Konten utama halaman home">
        <!-- Search Bar -->
        <section class="search-section">
          <div class="search-container">
            <input 
              type="text" 
              id="searchInput" 
              placeholder="Cari stories berdasarkan nama atau deskripsi..."
              class="search-input"
            />
            <button id="clearSearchBtn" class="clear-search-btn" style="display: none;">×</button>
          </div>
        </section>

        <!-- Loading State -->
        <div id="loadingState" class="loading-state" style="display: none;">
          <div class="loading-spinner"></div>
          <p>Memuat stories...</p>
        </div>

        <!-- Error State -->
        <div id="errorState" class="error-state" style="display: none;">
          <p class="error-message"></p>
          <button id="retryBtn" class="btn btn-primary">Coba Lagi</button>
        </div>

        <!-- Content -->
        <div class="home-content">
          <!-- Stories List -->
          <section class="stories-section">
            <h2 class="section-title">Semua Stories</h2>
            <div id="storiesList" class="stories-list">
              <!-- Stories akan dimuat di sini -->
            </div>
            <div id="emptyState" class="empty-state" style="display: none;">
              <p>Belum ada stories. Mulai dengan menambahkan story pertama Anda!</p>
              <button class="btn btn-primary" onclick="document.getElementById('addStoryBtn').click()">
                Tambah Story
              </button>
            </div>
          </section>
          
          <!-- Map Section -->
          <section class="map-section">
            <h2 class="section-title">Peta Lokasi Stories</h2>
            <div id="map" class="map-container"></div>
          </section>
        </div>
      </section>
    `;
  }

  async afterRender() {
    try {
      console.log('HomePage: Starting afterRender');

      // Set username in header
      this.updateUsernameDisplay();

      // Setup skip to content functionality
      this.setupSkipToContent();

      // Initialize map
      this.initializeMap();
      console.log('HomePage: Map initialized');

      // Setup event listeners
      this.setupEventListeners();
      console.log('HomePage: Event listeners setup');

      // Initialize presenter
      console.log('HomePage: Initializing presenter...');
      await this.presenter.init();
      console.log('HomePage: Presenter initialized');

    } catch (error) {
      console.error('HomePage: Error in afterRender:', error);
      this.showError('Gagal memuat halaman: ' + error.message);
    }
  }

  // Setup skip to content functionality
  setupSkipToContent() {
    // Find the skip to content link (it should be in the main template/layout)
    const skipLink = document.querySelector('.skip-link, [href="#main-content"], [data-skip-content]');
    
    if (skipLink) {
      // Remove any existing event listeners to prevent duplicates
      const newSkipLink = skipLink.cloneNode(true);
      skipLink.parentNode.replaceChild(newSkipLink, skipLink);
      
      // Add event listener for skip to content
      newSkipLink.addEventListener('click', (e) => {
        e.preventDefault();
        this.skipToMainContent();
      });

      // Also handle keyboard activation (Enter/Space)
      newSkipLink.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          this.skipToMainContent();
        }
      });

      console.log('Skip to content functionality setup completed');
    } else {
      console.warn('Skip to content link not found. Make sure it exists in your main template.');
    }
  }

  // Method to handle skip to content functionality
  skipToMainContent() {
    const mainContent = document.getElementById('main-content');
    const searchInput = document.getElementById('searchInput');
    
    if (mainContent && searchInput) {
      // First, set focus to the main content area (for screen readers)
      mainContent.focus();
      
      // Scroll to the main content if needed
      mainContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
      
      // Then immediately focus on the first interactive element (search input)
      // Use a small delay to ensure the scroll and focus operations don't conflict
      setTimeout(() => {
        searchInput.focus();
        console.log('Focus moved to search input after skip to content');
      }, 100);
      
      console.log('Skip to content executed - focus set to main content then search input');
      
      // Optional: Provide screen reader announcement
      this.announceToScreenReader('Melompat ke konten utama - fokus pada pencarian stories');
    } else {
      console.error('Main content element or search input not found');
    }
  }

  // Helper method for screen reader announcements
  announceToScreenReader(message) {
    // Create a temporary element for screen reader announcement
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only'; // This should be styled to be visually hidden
    announcement.textContent = message;
    
    // Add to document
    document.body.appendChild(announcement);
    
    // Remove after a short delay
    setTimeout(() => {
      if (announcement.parentNode) {
        announcement.parentNode.removeChild(announcement);
      }
    }, 1000);
  }

  // DOM/BOM Manipulation Methods (View responsibilities)
  
  updateUsernameDisplay() {
    const user = this.getUserData();
    const usernameElement = document.getElementById('username');
    if (usernameElement) {
      usernameElement.textContent = user.name || 'User';
    }
    console.log('HomePage: Username set to', user.name || 'User');
  }

  getUserData() {
    return {
      userId: localStorage.getItem('userId'),
      name: localStorage.getItem('userName'),
      token: localStorage.getItem('token')
    };
  }

  initializeMap() {
    try {
      const mapElement = document.getElementById('map');
      if (!mapElement) {
        console.error('Map element not found');
        return;
      }

      if (typeof L === 'undefined') {
        console.error('Leaflet library not loaded');
        return;
      }

      this.map = L.map('map').setView([-2.5489, 118.0149], 5);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(this.map);

      console.log('Map initialized successfully');
    } catch (error) {
      console.error('Error initializing map:', error);
    }
  }

  setupEventListeners() {
    try {
      // Add Story button
      const addStoryBtn = document.getElementById('addStoryBtn');
      if (addStoryBtn) {
        addStoryBtn.addEventListener('click', () => {
          this.presenter.onAddStoryClick();
        });
      }

      // Refresh button
      const refreshBtn = document.getElementById('refreshBtn');
      if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
          this.presenter.onRefreshClick();
        });
      }

      // Logout button
      const logoutBtn = document.getElementById('logoutBtn');
      if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
          this.presenter.onLogoutClick();
        });
      }

      // Search functionality with debouncing
      const searchInput = document.getElementById('searchInput');
      const clearSearchBtn = document.getElementById('clearSearchBtn');

      if (searchInput && clearSearchBtn) {
        searchInput.addEventListener('input', (e) => {
          const searchText = e.target.value;
          clearSearchBtn.style.display = searchText ? 'block' : 'none';
          
          // Clear previous timeout
          if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
          }
          
          // Set new timeout for search with debouncing
          this.searchTimeout = setTimeout(() => {
            this.presenter.onSearchInput(searchText);
          }, 300); // 300ms debounce
        });

        clearSearchBtn.addEventListener('click', () => {
          searchInput.value = '';
          clearSearchBtn.style.display = 'none';
          if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
          }
          this.presenter.onSearchClear();
        });
      }

      // Retry button
      const retryBtn = document.getElementById('retryBtn');
      if (retryBtn) {
        retryBtn.addEventListener('click', () => {
          this.presenter.onRetryClick();
        });
      }

      console.log('Event listeners setup completed');
    } catch (error) {
      console.error('Error setting up event listeners:', error);
    }
  }

  displayStories(stories) {
    try {
      console.log('HomePage: displayStories called with', stories);

      const storiesContainer = document.getElementById('storiesList');
      const emptyState = document.getElementById('emptyState');

      if (!storiesContainer) {
        console.error('Stories container not found');
        return;
      }

      if (!stories || stories.length === 0) {
        console.log('No stories to display');
        storiesContainer.innerHTML = '';
        if (emptyState) {
          emptyState.style.display = 'block';
        }
        return;
      }

      console.log(`Displaying ${stories.length} stories`);

      if (emptyState) {
        emptyState.style.display = 'none';
      }

      const storiesHTML = stories.map(story => {
        // Validate story data before rendering
        if (!story.id || !story.name || !story.photoUrl) {
          console.warn('Invalid story data:', story);
          return '';
        }

        return `
          <article class="story-card" data-story-id="${story.id}">
            <div class="story-image">
              <img src="${story.photoUrl}" alt="${this.escapeHtml(story.name)}" loading="lazy" 
                   onerror="this.src='data:image/svg+xml;charset=UTF-8,<svg xmlns=\\"http://www.w3.org/2000/svg\\" width=\\"200\\" height=\\"150\\" viewBox=\\"0 0 200 150\\"><rect width=\\"200\\" height=\\"150\\" fill=\\"#f0f0f0\\"/><text x=\\"100\\" y=\\"75\\" text-anchor=\\"middle\\" dy=\\".3em\\" font-family=\\"Arial\\" font-size=\\"12\\" fill=\\"#666\\">No Image</text></svg>'" />
            </div>
            <div class="story-content">
              <h3 class="story-title">${this.escapeHtml(story.name)}</h3>
              <p class="story-description">${this.escapeHtml(this.truncateText(story.description || '', 150))}</p>
              <div class="story-meta">
                <span class="story-date">
                  <span class="icon">📅</span>
                  ${this.formatDate(story.createdAt)}
                </span>
                ${story.hasLocation ? `
                  <span class="story-location">
                    <span class="icon">📍</span>
                    ${story.lat.toFixed(3)}, ${story.lon.toFixed(3)}
                  </span>
                ` : ''}
              </div>
              <div class="story-actions">
                ${story.hasLocation ? `
                  <button class="btn btn-outline view-location-btn" data-lat="${story.lat}" data-lon="${story.lon}">
                    Lihat di Peta
                  </button>
                ` : ''}
              </div>
            </div>
          </article>
        `;
      }).filter(html => html !== '').join('');

      storiesContainer.innerHTML = storiesHTML;
      console.log('Stories HTML updated');

      // Setup story-specific event listeners
      this.setupStoryEventListeners();
      console.log('Story event listeners setup');

    } catch (error) {
      console.error('Error displaying stories:', error);
      this.showError('Gagal menampilkan stories: ' + error.message);
    }
  }

  setupStoryEventListeners() {
    try {

      // View location buttons
      document.querySelectorAll('.view-location-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const lat = parseFloat(e.target.getAttribute('data-lat'));
          const lon = parseFloat(e.target.getAttribute('data-lon'));
          this.presenter.onLocationButtonClick(lat, lon);
        });
      });

      console.log(`Setup event listeners for ${document.querySelectorAll('.story-card').length} story cards`);
    } catch (error) {
      console.error('Error setting up story event listeners:', error);
    }
  }

  displayMap(stories) {
    try {
      if (!this.map) {
        console.warn('Map not initialized, skipping map display');
        return;
      }

      console.log('HomePage: displayMap called with', stories);

      // Clear existing markers
      this.markers.forEach(marker => {
        if (this.map) {
          this.map.removeLayer(marker);
        }
      });
      this.markers = [];

      const storiesWithLocation = stories.filter(story =>
        story.lat && story.lon &&
        !isNaN(story.lat) && !isNaN(story.lon)
      );

      console.log(`Found ${storiesWithLocation.length} stories with valid location`);

      if (storiesWithLocation.length === 0) {
        return;
      }

      // Add markers
      storiesWithLocation.forEach(story => {
        try {
          const marker = L.marker([story.lat, story.lon]).addTo(this.map);

          const popupContent = `
            <div class="map-popup">
              <img src="${story.photoUrl}" alt="${this.escapeHtml(story.name)}" class="popup-image" 
                   style="width: 200px; height: 150px; object-fit: cover; border-radius: 4px;" 
                   onerror="this.style.display='none'" />
              <h3 class="popup-title" style="margin: 8px 0 4px 0; font-size: 16px;">${this.escapeHtml(story.name)}</h3>
              <p class="popup-description" style="margin: 4px 0; font-size: 14px; color: #666;">${this.escapeHtml(this.truncateText(story.description || '', 100))}</p>
              <p class="popup-date" style="margin: 4px 0; font-size: 12px; color: #888;">${this.formatDate(story.createdAt)}</p>
            </div>
          `;

          marker.bindPopup(popupContent);
          this.markers.push(marker);

          // Add event listener for popup detail button
          marker.on('popupopen', () => {
            const popupDetailBtn = document.querySelector('.popup-detail-btn');
            if (popupDetailBtn) {
              popupDetailBtn.addEventListener('click', (e) => {
                const storyId = e.target.getAttribute('data-story-id');
                this.presenter.onStoryCardClick(storyId);
              });
            }
          });

        } catch (markerError) {
          console.error('Error creating marker for story:', story.id, markerError);
        }
      });

      // Fit map bounds to show all markers
      if (this.markers.length > 0) {
        try {
          const group = new L.featureGroup(this.markers);
          this.map.fitBounds(group.getBounds().pad(0.1));
        } catch (boundsError) {
          console.error('Error fitting map bounds:', boundsError);
        }
      }

      console.log(`Added ${this.markers.length} markers to map`);
    } catch (error) {
      console.error('Error displaying map:', error);
    }
  }

  centerMapOnLocation(lat, lon) {
    try {
      if (!this.map) {
        console.warn('Map not initialized');
        return;
      }

      this.map.setView([lat, lon], 15);

      // Open popup for the marker at this location
      this.markers.forEach(marker => {
        const markerLatLng = marker.getLatLng();
        if (Math.abs(markerLatLng.lat - lat) < 0.001 && Math.abs(markerLatLng.lng - lon) < 0.001) {
          marker.openPopup();
        }
      });

      console.log(`Centered map on location: ${lat}, ${lon}`);
    } catch (error) {
      console.error('Error centering map:', error);
    }
  }

  // UI State Management
  showLoading() {
    const loadingElement = document.getElementById('loadingState');
    const errorElement = document.getElementById('errorState');

    if (loadingElement) {
      loadingElement.style.display = 'block';
    }
    if (errorElement) {
      errorElement.style.display = 'none';
    }

    console.log('Loading state shown');
  }

  hideLoading() {
    const loadingElement = document.getElementById('loadingState');
    if (loadingElement) {
      loadingElement.style.display = 'none';
    }

    console.log('Loading state hidden');
  }

  showError(message) {
    const errorElement = document.getElementById('errorState');
    const errorMessageElement = document.querySelector('.error-message');
    const loadingElement = document.getElementById('loadingState');

    if (errorElement) {
      errorElement.style.display = 'block';
    }
    if (errorMessageElement) {
      errorMessageElement.textContent = message;
    }
    if (loadingElement) {
      loadingElement.style.display = 'none';
    }

    console.log('Error shown:', message);
  }

  // Navigation Methods (Browser/Router interactions)
  navigateToLogin() {
    window.location.hash = '#/login';
  }

  navigateToStoryDetail(storyId) {
    window.location.hash = `#/story/${storyId}`;
  }

  navigateToAddStory() {
    window.location.hash = '#/add';
  }

  // Session and Authentication Management
  handleSessionExpiry() {
    // Show a delayed logout to allow user to see the error message
    setTimeout(() => {
      this.handleLogout();
    }, 2000);
  }

  handleLogout() {
    // Clear localStorage
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');

    // Navigate to login
    this.navigateToLogin();
  }

  showLogoutConfirmation() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
      this.presenter.onLogoutConfirmed();
    }
  }

  // Utility Methods
  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  truncateText(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substr(0, maxLength) + '...';
  }

  formatDate(dateString) {
    try {
      if (!dateString) return 'Tanggal tidak tersedia';
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return 'Tanggal tidak valid';

      return date.toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch (error) {
      console.error('Error formatting date:', error);
      return 'Tanggal tidak valid';
    }
  }
}